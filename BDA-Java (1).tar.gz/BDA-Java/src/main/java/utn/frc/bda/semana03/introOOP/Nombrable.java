package utn.frc.bda.semana03.introOOP;

public interface Nombrable {
    public void nombrar(String s1, String s2);

    public String obtenerNombre();
}

package utn.frc.bda.semana05.jdbc.domain;

public class Curso {
}

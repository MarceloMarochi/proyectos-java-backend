package utn.frc.bda.util.menu;

public interface MenuCall {
    //todo: ver interfaz funcional Callable
    void call();
}

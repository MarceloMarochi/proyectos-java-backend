package utn.frc.bda.semana03.menuItems;

import utn.frc.bda.util.menu.MenuCall;

public class MenuCallNPrimos implements MenuCall {

    @Override
    public void call() {
        System.out.println("N Primos");
        //NPrimos.run();
    }
}
